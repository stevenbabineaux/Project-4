#include "syscall.h"

int main()
{
	Exec("../test/loop");
}
